# Install-dlib

### download file above and then install it 
make sure the version is the same as your pyton version

### After download the file 
make sure you are in the same folder/directory with the dlib that you already download
then type in your terminal -> pip install (yourfile, example : dlib-19.19.0-cp37-cp37m-win_amd64.whl)
then press enter wait untill the process of the installation finish

Complete video guide : https://youtu.be/ot6LWpZjTXo

### If you are installing dlib on python 3.7 or 3.8
Then download whl file from this repository and follow below episode to install it - https://youtu.be/AUJKdehF2ZA
